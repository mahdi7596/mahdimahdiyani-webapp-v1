/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Vazirmatn', 'sans-serif'],
        serif: ['Vazirmatn', 'sans-serif'],
      },
      colors: {
        primary: 'var(--primary)',
        'primary-900': 'var(--primary-900)',
        'primary-800': 'var(--primary-800)',
        'primary-700': 'var(--primary-700)',
        'primary-600': 'var(--primary-600)',
        'primary-500': 'var(--primary-500)',
        'primary-400': 'var(--primary-400)',
        'primary-300': 'var(--primary-300)',
        'primary-200': 'var(--primary-200)',
        'primary-100': 'var(--primary-100)',
        'primary-0': 'var(--primary-0)',
        neutrals: 'var(--neutrals)',
        'neutrals-600': 'var(--neutrals-600)',
        'neutrals-500': 'var(--neutrals-500)',
        'neutrals-400': 'var(--neutrals-400)',
        'neutrals-300': 'var(--neutrals-300)',
        'neutrals-200': 'var(--neutrals-200)',
        'neutrals-100': 'var(--neutrals-100)',
        surfaceBg: 'var(--surfaceBg)',
        surfaceBorder: 'var(--surfaceBorder)',
        backgroundColor: 'var(--backgroundColor)',
        info: 'var(--info)',
        success: 'var(--success)',
        warn: 'var(--warn)',
        danger: 'var(--danger)',
        teal: 'var(--teal)',
      },
    },
  },
  plugins: [require('daisyui')],
  daisyui: {
    themes: [
      {
        light: {
          ...require('daisyui/src/theming/themes')['light'],
          primary: 'var(--primary)',
          secondary: 'var(--neutrals-400)',
          accent: 'var(--primary-500)',
        },
      },
    ],
  },
};
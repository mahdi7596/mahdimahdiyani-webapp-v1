import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { ArrowRight } from 'lucide-react';

interface Statistic {
  value: number;
  label: string;
  suffix: string;
}

const statistics: Statistic[] = [
  { value: 10, label: 'Years of experience', suffix: '+' },
  { value: 100, label: 'Estate Plans Created', suffix: '+' },
  { value: 250, label: 'Cases Handled', suffix: '+' },
  { value: 400, label: 'Court Appearances Made', suffix: '+' },
];

const Counter = ({ value, label, suffix }: Statistic) => {
  const [count, setCount] = useState(0);
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.5,
  });

  useEffect(() => {
    if (inView) {
      const duration = 2000; // 2 seconds
      const steps = 60;
      const increment = value / steps;
      let current = 0;
      const timer = setInterval(() => {
        current += increment;
        if (current >= value) {
          setCount(value);
          clearInterval(timer);
        } else {
          setCount(Math.floor(current));
        }
      }, duration / steps);
      return () => clearInterval(timer);
    }
  }, [inView, value]);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.8 }}
      className="text-center"
    >
      <div className="text-5xl md:text-6xl font-serif mb-2">
        {count}{suffix}
      </div>
      <div className="text-gray-500">{label}</div>
    </motion.div>
  );
};

const About = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <section id="about" className="py-24">
      <div className="container mx-auto px-4">
        {/* Dark Background Section */}
        <div className="bg-[#1E2A40] rounded-3xl overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Image */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={inView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8 }}
              className="p-8"
            >
              <div className="rounded-3xl overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&q=80&w=2071"
                  alt="Professional Lawyer"
                  className="w-full h-[600px] object-cover"
                />
              </div>
            </motion.div>

            {/* Content */}
            <motion.div
              ref={ref}
              initial={{ opacity: 0, x: 50 }}
              animate={inView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8 }}
              className="p-8 lg:pr-12"
            >
              <span className="text-gray-400 uppercase tracking-wider text-sm">ABOUT ME</span>
              <h2 className="text-4xl md:text-5xl font-serif text-white mt-4 mb-6">
                Expert Legal Services<br />Tailored for You
              </h2>
              <p className="text-gray-300 mb-8">
                A graduate of the University of Texas School of Law and a member of the Texas Bar Association, 
                I pride myself on integrity and transparency. I strive to simplify legal processes for my clients, 
                offering clear guidance every step of the way. You can count on me to be your dedicated advocate 
                and trusted legal partner.
              </p>
              <motion.a
                href="#"
                className="inline-flex items-center text-white hover:text-gray-300 transition-colors"
                whileHover={{ x: 5 }}
              >
                More about me <ArrowRight size={18} className="ml-2" />
              </motion.a>
            </motion.div>
          </div>
        </div>

        {/* Statistics Section */}
        <div className="mt-24 grid grid-cols-2 md:grid-cols-4 gap-8">
          {statistics.map((stat) => (
            <Counter key={stat.label} {...stat} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;
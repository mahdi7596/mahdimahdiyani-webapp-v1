import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Code2, Database, Layout, Smartphone } from 'lucide-react';

interface Service {
  title: string;
  description: string;
  icon: React.ReactNode;
}

const services: Service[] = [
  {
    title: "توسعه وب‌سایت",
    description: "طراحی و توسعه وب‌سایت‌های مدرن و واکنش‌گرا با استفاده از جدیدترین تکنولوژی‌های روز دنیا",
    icon: <Layout className="w-6 h-6" />
  },
  {
    title: "گزارش‌های مالی",
    description: "تهیه و تحلیل گزارش‌های مالی دقیق برای کسب‌وکار شما",
    icon: <Database className="w-6 h-6" />
  },
  {
    title: "درخواست خدمات",
    description: "مدیریت کارآمد درخواست‌های خدمات و سفارشات از طریق پلتفرم ما",
    icon: <Code2 className="w-6 h-6" />
  },
  {
    title: "مدیریت مشتریان",
    description: "پیگیری اطلاعات مشتریان و قراردادها به صورت یکپارچه و حرفه‌ای",
    icon: <Smartphone className="w-6 h-6" />
  }
];

const Contact = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  return (
    <section id="contact" className="py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="max-w-6xl mx-auto"
        >
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">خدمات مدیریتی</h2>
            <p className="text-xl text-gray-600">راهکارهای هوشمند برای مدیریت کسب‌وکار شما</p>
          </div>

          <div className="space-y-8">
            {/* First Row */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8 }}
                className="lg:col-span-2 bg-white rounded-3xl p-8 shadow-sm hover:shadow-xl transition-all duration-300"
              >
                <div className="flex items-start gap-4">
                  <div className="bg-[#2B3A55]/10 p-3 rounded-2xl">
                    {services[0].icon}
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold mb-3">{services[0].title}</h3>
                    <p className="text-gray-600 leading-relaxed">{services[0].description}</p>
                  </div>
                </div>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="bg-white rounded-3xl p-8 shadow-sm hover:shadow-xl transition-all duration-300"
              >
                <div className="flex items-start gap-4">
                  <div className="bg-[#2B3A55]/10 p-3 rounded-2xl">
                    {services[1].icon}
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold mb-3">{services[1].title}</h3>
                    <p className="text-gray-600 leading-relaxed">{services[1].description}</p>
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Second Row */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: 0.3 }}
                className="bg-white rounded-3xl p-8 shadow-sm hover:shadow-xl transition-all duration-300"
              >
                <div className="flex items-start gap-4">
                  <div className="bg-[#2B3A55]/10 p-3 rounded-2xl">
                    {services[2].icon}
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold mb-3">{services[2].title}</h3>
                    <p className="text-gray-600 leading-relaxed">{services[2].description}</p>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="lg:col-span-2 bg-white rounded-3xl p-8 shadow-sm hover:shadow-xl transition-all duration-300"
              >
                <div className="flex items-start gap-4">
                  <div className="bg-[#2B3A55]/10 p-3 rounded-2xl">
                    {services[3].icon}
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold mb-3">{services[3].title}</h3>
                    <p className="text-gray-600 leading-relaxed">{services[3].description}</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Contact;
import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { ArrowLeft } from 'lucide-react';

interface Specialization {
  title: string;
  description: string;
}

const specializations: Specialization[] = [
  {
    title: "توسعه فرانت‌اند",
    description: "طراحی و توسعه رابط‌های کاربری مدرن با React و Next.js"
  },
  {
    title: "توسعه بک‌اند",
    description: "ایجاد API‌های قدرتمند با Node.js و Express"
  },
  {
    title: "طراحی UI/UX",
    description: "طراحی رابط‌های کاربری زیبا و کاربرپسند"
  },
  {
    title: "توسعه موبایل",
    description: "ساخت اپلیکیشن‌های موبایل با React Native"
  },
  {
    title: "مشاوره فنی",
    description: "ارائه راهکارهای فنی برای کسب‌وکارها"
  },
  {
    title: "بهینه‌سازی عملکرد",
    description: "بهبود سرعت و کارایی وب‌سایت‌ها"
  }
];

const Work = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  return (
    <section id="portfolio" className="py-24 bg-[#F8F9FC]">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="max-w-6xl mx-auto"
        >
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-4xl md:text-5xl font-bold text-primary mb-16 text-center"
          >
            تخصص‌های من
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {specializations.map((spec, index) => (
              <motion.div
                key={spec.title}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                className="bg-white rounded-3xl p-8 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="h-1 w-8 bg-[#2B3A55] mb-6"></div>
                <h3 className="text-2xl font-bold text-primary mb-4">{spec.title}</h3>
                <p className="text-gray-600 mb-6">{spec.description}</p>
                <motion.a
                  href="#"
                  className="inline-flex items-center text-primary hover:text-[#2B3A55] transition-colors"
                  whileHover={{ x: -5 }}
                >
                  بیشتر بخوانید <ArrowLeft size={18} className="mr-2" />
                </motion.a>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mt-12 text-center"
          >
            <motion.a
              href="#"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="inline-flex items-center gap-2 px-6 py-3 bg-[#2B3A55] text-white rounded-full hover:bg-[#1E2A40] transition-colors"
            >
              مشاهده همه نمونه کارها
              <ArrowLeft size={18} />
            </motion.a>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Work;
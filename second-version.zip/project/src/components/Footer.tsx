import React from 'react';
import { motion } from 'framer-motion';

const Footer = () => {
  return (
    <footer className="py-8 bg-white border-t border-gray-100">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="text-secondary"
          >
            © {new Date().getFullYear()} All rights reserved
          </motion.p>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="mt-4 md:mt-0"
          >
            <nav className="flex space-x-6">
              <a href="#work" className="text-secondary hover:text-accent transition-colors">Work</a>
              <a href="#about" className="text-secondary hover:text-accent transition-colors">About</a>
              <a href="#contact" className="text-secondary hover:text-accent transition-colors">Contact</a>
            </nav>
          </motion.div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
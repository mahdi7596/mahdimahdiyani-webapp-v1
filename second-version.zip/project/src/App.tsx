import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Work from './components/Work';
import About from './components/About';
import Contact from './components/Contact';
import Experience from './components/Experience';
import ExperienceShowcase from './components/ExperienceShowcase';
import Footer from './components/Footer';

function App() {
  return (
    <AnimatePresence>
      <div className="bg-backgroundColor">
        <Navbar />
        <Hero />
        <Work />
        <About />
        <Experience />
        <ExperienceShowcase />
        <Contact />
        <Footer />
      </div>
    </AnimatePresence>
  );
}

export default App;